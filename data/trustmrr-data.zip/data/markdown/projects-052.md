# TrustMRR公开项目 12751–12964 / 12964
无预筛；功能/类别为来源原文。收入非利润；目录值可能舍入；未知不等于0；新入池/成立日不代表上线。
|slug / 产品|功能原文|原站类别|MRR / 30天 / 累计（USD）|来源级别|链接|
|---|---|---|---|---|---|
|astrak / AstraK|Provides B2B growth, lead generation, CRM and Salesforce consulting, plus marketing and automation services for local appointment-based businesses.|未知|$1.5k / $1.5k / $1.9k|D|[TrustMRR](https://trustmrr.com/startup/astrak)|
|backseat-poker / Backseat Poker|Coach your Agent at Poker to become the season bracelet winner.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/backseat-poker)|
|blocktale / Blocktale|Create viral shorts and videos in minutes|未知|$0 / $29 / $29|D|[TrustMRR](https://trustmrr.com/startup/blocktale)|
|briefsketch / Briefsketch|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/briefsketch)|
|burglar-ai / Burglar AI|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/burglar-ai)|
|buying-signals-mcp / Buying Signals MCP|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/buying-signals-mcp)|
|checklist-routines / Checklist Routines|Just routines with checklists! What else do you need?|未知|$2 / $129 / $184|D|[TrustMRR](https://trustmrr.com/startup/checklist-routines)|
|citemap / CiteMap|CiteMap shows whether AI recommends your brand, or your competitors. Enter your site and real buyer questions to get a visibility score, the competitors AI names instead, the sources it cites, and a s|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/citemap)|
|claimyourspot / ClaimYourSpot|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/claimyourspot)|
|clickspal / ClicksPal|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/clickspal)|
|cliplookout / ClipLookout|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/cliplookout)|
|clutchreel / ClutchReel|ClutchReel is a clip-prep studio for creators. Import a YouTube link, direct media file or upload, and it proposes highlight candidates with timestamps and the evidence behind each one — transcript, H|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/clutchreel)|
|cmokit / CMOkit|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/cmokit)|
|comurank / Comurank|Affiliate programs for course creators, in 10 minutes|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/comurank)|
|confidential-startup-86 / Anonymous startup|未知|未知|$13 / $0 / $45|D|[TrustMRR](https://trustmrr.com/startup/confidential-startup-86)|
|confidential-startup-87 / Anonymous startup|未知|未知|$0 / $8 / $12|D|[TrustMRR](https://trustmrr.com/startup/confidential-startup-87)|
|confidential-startup-88 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/confidential-startup-88)|
|cutskills / CutSkills|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/cutskills)|
|dairylogs / DairyLogs|Cloud-based dairy farm management software. Track every animal, milk yields, breeding and pregnancy, health treatments, feed and farm finances in one place, with automatic reminders and task lists. Bu|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/dairylogs)|
|david-meili / Terra Incognita|Terra Incognita is the field diary for overlanders: log each camp, what you spent and what you saw, and it turns your trip into a map, stats and a story worth sharing.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/david-meili)|
|do-small / Do Small|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/do-small)|
|easycoexistence / easyCoexistence|easyCoexistence is a multichannel API and MCP server for AI agents. From Claude, ChatGPT or your own platform, publish and schedule posts, read analytics, build automations and flows like comment-to-D|未知|$1.2k / $1.6k / $2.4k|D|[TrustMRR](https://trustmrr.com/startup/easycoexistence)|
|emailoutreach / EmailOutReach|Tell us who you sell to. We find them and email them for you. Every day, Smart Email Outreach finds real people who fit your business, writes each one a personal email from your own address, and draft|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/emailoutreach)|
|emergent-fm / emergent.fm|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/emergent-fm)|
|eodlens / EODLens|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/eodlens)|
|firstpass / FirstPass|FirstPass checks iOS app builds and App Store listings against Apple's App Review guidelines, helping developers spot common rejection risks and fix issues before submitting.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/firstpass)|
|fiscalist / Fiscalist|Fiscalist helps Romanian accountants and businesses answer tax questions from the Cod fiscal, its methodological norms and the Cod de procedură fiscală. Answers cite legal articles and verified source|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/fiscalist)|
|foodchain / Foodchain|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/foodchain)|
|founderdesk / founderdesk|FounderDesk turns your Mac desktop into a live dashboard for your startup. Every Stripe sale slides down as a notification, and cartoon widgets on your wallpaper show today's revenue, visitors online,|未知|$9 / $9 / $9|D|[TrustMRR](https://trustmrr.com/startup/founderdesk)|
|foundgpt / FoundGPT|FoundGPT is a Shopify app that shows merchants whether ChatGPT, Gemini, Perplexity, Claude and Google AI Mode recommend their store or a competitor, and then helps fix the gaps. Auto-Fix rewrites prod|未知|$174 / $158 / $549|D|[TrustMRR](https://trustmrr.com/startup/foundgpt)|
|futurepost / Futurepost|Free browser extension for X that adds bulk unfollow, follower cleanup, unfollower tracking and scam/bot labels. It runs in your own tab and never asks for your password. Pro ($9.99/mo) adds post sche|未知|$142 / $234 / $270|D|[TrustMRR](https://trustmrr.com/startup/futurepost)|
|generato / Generato|Generato is a multidisciplinary studio that builds custom 3D, XR, and applied AI experiences and products for brands and organizations.|未知|$0 / $28 / $94|D|[TrustMRR](https://trustmrr.com/startup/generato)|
|gold-rate / Gold Rate|未知|未知|$9 / $48 / $48|D|[TrustMRR](https://trustmrr.com/startup/gold-rate)|
|hebby-learn / Hebby Learn|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/hebby-learn)|
|herewith / HereWith|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/herewith)|
|hidden-business-98 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/hidden-business-98)|
|hidden-business-99 / Snowy Mac App|未知|未知|$0 / $12 / $12|D|[TrustMRR](https://trustmrr.com/startup/hidden-business-99)|
|house-goals / House Goals|House Goals is an AI interior design app for iPhone. Users snap a photo of any room or garden and get photorealistic redesigns in seconds, then fine-tune them with targeted edits like swapping furnitu|未知|$8.5k / $9.2k / $60k|D|[TrustMRR](https://trustmrr.com/startup/house-goals)|
|imp-act / IMP-ACT|IMP-ACT is an AI-powered habit-building and personal productivity app designed to help people organize their daily lives without the overwhelm. Instead of manually planning everything, users get perso|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/imp-act)|
|item-get / Item Get!|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/item-get)|
|keepercut / Keepercut|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/keepercut)|
|kid-draw / Kid Draw|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/kid-draw)|
|leadjarvas / LeadJarvas|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/leadjarvas)|
|liga-taekwondo / Liga Taekwondo|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/liga-taekwondo)|
|linklane / LinkLane|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/linklane)|
|loyalius / Loyalius|Loyalius is a digital loyalty card platform for cafés, restaurants, salons, shops and small chains. Customers scan a QR code and keep a stamp, points or cashback card in Apple Wallet or Google Wallet:|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/loyalius)|
|magic-maps-3d-gps-navigation / Magic Maps: 3D GPS Navigation|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/magic-maps-3d-gps-navigation)|
|magicwebsite / MagicWebsite|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/magicwebsite)|
|magnetic-funnels-1 / Magnetic Funnels|We build intelligent systems that work 24/7 for businesses, turning your operations into an automated growth machine.|未知|$831 / $8.5k / $69k|D|[TrustMRR](https://trustmrr.com/startup/magnetic-funnels-1)|
|metaone-ag / Exhibase|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/metaone-ag)|
|mindtrade / MINDTRADE|MindTrade is a trading psychology SaaS designed to help traders improve discipline, track emotional patterns, identify harmful trading behaviors, and monitor their psychological performance through da|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/mindtrade)|
|mirofish-ai / Mirofish AI|Turns ideas, documents, headlines, and market signals into interactive AI simulations and actionable reports showing potential public opinion, market responses, and strategic outcomes.|未知|$842 / $642 / $11k|D|[TrustMRR](https://trustmrr.com/startup/mirofish-ai)|
|mrr-studio / MRR Studio|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/mrr-studio)|
|myclass-games / MyClass.games|Explore classroom games made with teachers in mind. Open one, put it on the projector and play with your whole class.|未知|$0 / $6 / $1.3k|D|[TrustMRR](https://trustmrr.com/startup/myclass-games)|
|nennly / Nennly|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/nennly)|
|nightdraw / NightDraw: Tarot Card Reading|NightDraw is an iOS app for people who love tarot but find most apps cluttered and generic. Pick a spread, draw your cards, and get a reading written for your question, along with daily cards, a journ|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/nightdraw)|
|one-frame-each / One Frame Each|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/one-frame-each)|
|opening-day / Opening day|Thoughtful apps that help people build a healthier relationship with technology, starting with a virtual pet that encourages less phone use.|未知|$0 / $2 / $2|D|[TrustMRR](https://trustmrr.com/startup/opening-day)|
|openorsteal / Open or Steal|Open or Steal is an online white elephant gift exchange played as a live party game. One shared screen shows a 3D room with everyone around a table of gifts, and phones become the controllers. On each|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/openorsteal)|
|ownletters / OwnLetters|Newsletter on autopilot for creators. Paste your Instagram, TikTok, YouTube or X link: OwnLetters reads your posts, writes your weekly newsletter in your voice and sends it to your subscribers. Own yo|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/ownletters)|
|panefold / PaneFold|PaneFold is a native Mac window and workspace manager. Save a setup for each project and bring back its apps, windows, supported browser tabs and files with a shortcut. Other apps hide without quittin|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/panefold)|
|pattern-space / Pattern Space|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/pattern-space)|
|perch / Perch|Perch adds a live notch to the top of your Windows screen. Hover it to control music, run timers, see notifications, browse clipboard history, keep files on a shelf, search apps and files, and approve|未知|$0 / $11 / $11|D|[TrustMRR](https://trustmrr.com/startup/perch)|
|pong-chat / PONG CHAT - Live chat for your website. With AI and video.|PONG CHAT is a free live chat widget for websites with AI-powered customer support, real-time visitor tracking, and browser-based video calls. Add live chat to any website in minutes with a single scr|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/pong-chat)|
|postpicnic / PostPicnic|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/postpicnic)|
|pozea / Pozea: Pose Ideas & Camera|It helps people pose better on camera|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/pozea)|
|prakriti / Prakriti|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/prakriti)|
|private-enterprise-96 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-enterprise-96)|
|private-enterprise-97 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-enterprise-97)|
|private-venture-106 / Anonymous startup|未知|未知|$1.2k / $985 / $1.9k|D|[TrustMRR](https://trustmrr.com/startup/private-venture-106)|
|private-venture-107 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-venture-107)|
|private-venture-108 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-venture-108)|
|private-venture-109 / Anonymous startup|未知|未知|$0 / $0 / $30|D|[TrustMRR](https://trustmrr.com/startup/private-venture-109)|
|qr-honey / QR Honey|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/qr-honey)|
|rankedbyai-dev / RankedByAi.dev|When buyers ask ChatGPT, Claude, Perplexity, Gemini or Grok for the best tool in your category, are you in the answer? RankedByAi.dev runs the searches your buyers make, with web search on, and shows|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/rankedbyai-dev)|
|ratio / Ratio|A private, cross-platform notepad calculator that turns plain-text notes into live answers for math, currencies, units, dates, and time zones.|未知|$0 / $153 / $180|D|[TrustMRR](https://trustmrr.com/startup/ratio)|
|razorpay-business-19 / Razorpay business|未知|未知|$0 / $11 / $11|D|[TrustMRR](https://trustmrr.com/startup/razorpay-business-19)|
|recpix / RecPix|RecPix records product tutorials for you. Paste a link and describe a flow, like "schedule a video on YouTube": it clicks through your product, narrates every step and exports a finished tutorial with|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/recpix)|
|reelspack / Reelspack|AI ad creatives and video hooks for Shopify products.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/reelspack)|
|roomprint-floor-plan-scanner / Roomprint: Floor Plan Scanner|Scan your home into a measured floor plan in minutes. See it in 3D, try paint and flooring, then print it to scale. Free to scan and plan. No subscription, ever.|未知|$0 / $49 / $49|D|[TrustMRR](https://trustmrr.com/startup/roomprint-floor-plan-scanner)|
|saidur-said / Saidur Said|Rumbo turns short daily updates about your goals into supportive scores, insights, and visual trends so you can track your direction over time.|未知|$0 / $0 / $1|D|[TrustMRR](https://trustmrr.com/startup/saidur-said)|
|salesintros / SalesIntros|SalesIntros is a self-serve marketplace that matches B2B companies with qualified business leaders who want to take sales meetings. Vendors enter their website, AI drafts their ideal buyer and qualify|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/salesintros)|
|salon / Salon: Learn Art History|Salon helps you find your taste in art and learn to really see paintings. Swipe through famous works to get a taste card that names your eye. Then learn one movement at a time with five-minute lessons|未知|$0 / $17 / $17|D|[TrustMRR](https://trustmrr.com/startup/salon)|
|scandalous-ai / Scandalous AI|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/scandalous-ai)|
|securegrade / SecureGrade|Daily external security scans that grade websites A to F and say exactly what to fix.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/securegrade)|
|sendforever-solo / SendForever Solo|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/sendforever-solo)|
|share-me-di-edoardo-taj / On Pace|On pace is a challenge platform for run clubs and sports communities. Organizers create a challenge in minutes, like "100 km in November", share it with members and offer a reward from the club or a s|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/share-me-di-edoardo-taj)|
|shingle / Shingle|Shingle builds websites for local businesses. Describe a business in a few sentences, refine the site in plain words and publish it.|未知|$78 / $1 / $1|D|[TrustMRR](https://trustmrr.com/startup/shingle)|
|shipspace / ShipSpace|virtual internet cafe for builders|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/shipspace)|
|silqy / Silqy|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/silqy)|
|simple-ai-tracker / Simple AI Tracker|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/simple-ai-tracker)|
|smartprocesslab / Smartprocesslab|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/smartprocesslab)|
|snappd / Snappd|Screen recording for the Mac that stays out of your way.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/snappd)|
|snipzy / Snipzy|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/snipzy)|
|soldpage / soldpage|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/soldpage)|
|sore / Sore|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/sore)|
|sponsrs / Sponsrs|Sponsrs is a two-sided sponsorship intelligence platform and database that connects both sides of the creator economy: content creators looking for funding and brands/marketers looking to run influenc|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/sponsrs)|
|starring-you-two / Starring You Two|“Starring You Two turns a couple’s love story into a 30, 60 or 90-second AI film starring the two of them, made from their photos and delivered on their order page within 30 minutes.”|未知|$0 / $1 / $1|D|[TrustMRR](https://trustmrr.com/startup/starring-you-two)|
|stealth-company-109 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/stealth-company-109)|
|stealth-company-110 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/stealth-company-110)|
|stealth-company-111 / Anonymous startup|未知|未知|$0 / $0 / $10|D|[TrustMRR](https://trustmrr.com/startup/stealth-company-111)|
|stealth-venture-72 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/stealth-venture-72)|
|stockruum / Stockruum|A cloud-based warehouse management software (SaaS) for third-party logistics (3PL) and warehouse businesses. Customers pay a monthly or annual subscription to manage stock, goods in and out, customer|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/stockruum)|
|talkto / TalkTo|Messaging for agents|未知|$16 / $62 / $62|D|[TrustMRR](https://trustmrr.com/startup/talkto)|
|tapclip / TapClip|TapClip is a mobile-first AI video tool: create a consistent avatar once, then tap to generate short social clips (≈10–15s) for daily content or product promo — no model pickers, no token UI. Preview|未知|$0 / $11 / $11|D|[TrustMRR](https://trustmrr.com/startup/tapclip)|
|tenjiku / Dumree|Dumree helps freelancers and indie developers import CSV transactions and review income, expenses, and net income by currency.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/tenjiku)|
|tinyorder / TinyOrder|A platform for home business owners to manage their orders|未知|$10 / $10 / $46|D|[TrustMRR](https://trustmrr.com/startup/tinyorder)|
|trackero / Trackero|Create trackable QR codes and short links for your clients or for your business.|未知|$0 / $0 / $9|D|[TrustMRR](https://trustmrr.com/startup/trackero)|
|trydistribute / Distribute|Building got easy. Getting paying customers is the hard part. Our AI agent spots what's trending in your vertical, makes your UGC videos, runs your social media, writes articles that rank, improves SE|未知|$19 / $19 / $19|D|[TrustMRR](https://trustmrr.com/startup/trydistribute)|
|unmentioned / Unmentioned|AI visibility audit for founders. See who ChatGPT and Claude recommend instead of you, where those names come from, and get the messages that ask for your spot. $49, one-time.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/unmentioned)|
|unnamed-company-73 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/unnamed-company-73)|
|unnamed-company-74 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/unnamed-company-74)|
|unravel-reader / Unravel Reader|Unravel Reader is a side-by-side reader for hard books. The original page sits on the left and that exact page, explained in plain words, sits on the right, in sync as you turn pages. Tap any word for|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/unravel-reader)|
|waitlist / Waitlist|This startup is a self-serve waitlist platform for founders and makers launching a product. Instead of stitching together a landing page, a referral tool, and an email list, customers create a branded|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/waitlist)|
|wifriends / WiFriends|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/wifriends)|
|yeepa / Yeepa|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/yeepa)|
|yuletails / Yuletails|Holiday pet portrait and greeting card studio. Typable greeting and print-ready cards. One-off $12 one-pet pack or $24 family pack for up to 3 pets.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/yuletails)|
|ziffy-tools / Ziffy Tools|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/ziffy-tools)|
|24bisous / 24 Bisous|Digital advent calendars made of your memories: photos, voice notes and messages behind 24 doors, one opening each day. For a partner, a parent, a best friend or someone far away.|未知|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/24bisous) [官网](https://24bisous.com/)|
|24littlegifts / 24LittleGifts|The personalised digital advent calendar you give as a gift|未知|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/24littlegifts) [官网](https://24littlegifts.com/)|
|3am-texts / 3AM Texts: AI Love Stories|Some conversations only happen at 3am. 3AM Texts is an interactive story app where you match with fictional characters and text them like a real person, late at night, when the best conversations happen. Every character is an AI with their own life, mood, schedule and secrets, and every story grows with you.|Mobile Apps|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/3am-texts) [官网](https://apps.apple.com/us/app/3am-texts-ai-love-stories/id6833118377?uo=4)|
|ai-jungle-llc / GreeftForU|Tell Baibot, a robot baboon, three things about someone. He casts them as their totem animal in a 20-second nature documentary, or makes an object thank them by name. For businesses: a thank-you film for each customer, and a second film they pass on to a friend with your name and offer inside. There's no better lead than a happy customer's friend.|Marketing|$0.00 / $0.00 / $12.00|P|[TrustMRR](https://trustmrr.com/startup/ai-jungle-llc) [官网](https://greeftforu.com/)|
|aibar-one-time-license / aibar — one-time license|**aibar** puts your AI coding agents in a bar at the edge of your screen. - Run Claude Code, Codex and Gemini CLI without opening a terminal - See every agent's status at a glance, approve commands, review changes and reply - macOS, Windows and Linux - Use it on up to 3 of your computers - All 1.x updates included - 14-day money-back guarantee Your license key arrives by email right after purchase…〔全文见JSON〕|未知|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/aibar-one-time-license) [官网](https://aibar.dev/)|
|alpha-jaya-inovasi / Breakout Brief|未知|未知|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/alpha-jaya-inovasi) [官网](https://breakoutbrief.com/)|
|amazonseller / amazonseller.app|未知|未知|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/amazonseller) [官网](https://amazonseller.app/)|
|anonymous-startup-90 / Stealth Company|未知|未知|$0.00 / $0.00 / $0.00|P|[TrustMRR](https://trustmrr.com/startup/anonymous-startup-90)|
|anonymous-startup-91 / Anonymous startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/anonymous-startup-91)|
|anonymous-startup-92 / Anonymous Startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/anonymous-startup-92)|
|auditdrop / AuditDrop|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/auditdrop)|
|beskidy-xyz-sp-z-o-o / Pobyt w Górach.pl|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/beskidy-xyz-sp-z-o-o)|
|blast-usa-inc / Cherpa|Cherpa is an all-in-one business operating platform that brings your essential tools - CRM, CMS, Signing, and more—into one simple, unified workspace. Spend less time managing software and more time g|未知|$99 / $99 / $99|D|[TrustMRR](https://trustmrr.com/startup/blast-usa-inc)|
|bookiesk / BookiesK|BookiesK is an iOS sports social platform connecting football fans through match discussions, shared analysis, picks and community interaction.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/bookiesk)|
|canireverseengineer / canireverseengineer|Find out how hard a software product is to clone before you build it. Each teardown gives a difficulty score (1-5), a build estimate in days for one developer using AI coding agents, the likely tech stack, the hardest problems, open-source alternatives and an MVP plan. Request any product and our AI research pipeline writes a sourced report. Built for indie hackers, founders and researchers, with …〔全文见JSON〕|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/canireverseengineer)|
|cliprunner / Cliprunner|Cliping large streams, on autopilot|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/cliprunner)|
|confidential-startup-89 / Confidential Startup|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/confidential-startup-89)|
|coupar / Coupar|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/coupar)|
|cozymac / CozyMac|A cozy Mac app that brings snow, rain, and live weather to your desktop.|未知|$0 / $5.2k / $5.2k|D|[TrustMRR](https://trustmrr.com/startup/cozymac)|
|duly / Duly|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/duly)|
|embebee / Embebee|The hive that lets any AI plug into ready-made roles and connectors.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/embebee)|
|facet / Facet|A free, privacy-focused Mac browser that combines Chrome extensions, touch-friendly controls, built-in AI tools and agents, and customizable workspaces.|未知|$7 / $826 / $826|D|[TrustMRR](https://trustmrr.com/startup/facet)|
|focus-bard / Focus Bard|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/focus-bard)|
|groovescope / GrooveScope|Chrome extension that renders audio waveforms below YouTube videos for music producers hunting for loops and samples.|未知|$15 / $12 / $110|D|[TrustMRR](https://trustmrr.com/startup/groovescope)|
|habitfill / HabitFill Habit Tracker|HabitFill helps you build routines that last. Create habits, set schedules, and track your progress with a clear, distraction-free experience designed to make daily consistency easier.|未知|$48 / $43 / $136|D|[TrustMRR](https://trustmrr.com/startup/habitfill)|
|haggling / Haggling|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/haggling)|
|hidden-business-100 / Anonymous startup|未知|未知|$0 / $1 / $1|D|[TrustMRR](https://trustmrr.com/startup/hidden-business-100)|
|hidden-business-101 / Hidden Business|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/hidden-business-101)|
|hidden-business-102 / Hidden Business|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/hidden-business-102)|
|hookroast-creator-pass / HookRoast|Stop losing viewers in the first 3 seconds. Get a full year of AI-powered hook and retention diagnostics for TikTok, Instagram Reels, and YouTube Shorts—for less than $3.25/month, billed once a year.  What's included:  Full-Year Hook & Retention Roasts: Test every draft before you publish without worrying about monthly credit limits.  0–3s Scroll-Stop Score: Frame-by-frame visual and pacing audit …〔全文见JSON〕|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/hookroast-creator-pass)|
|hueggenberg / Pushreel|A plugin for Claude Code. Type /pushreel in your project and get a YouTube Short, an Instagram Reel and a TikTok of your web app, recorded and cut on your machine. One license for one person, active o|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/hueggenberg)|
|indexing-doctor / Indexing Doctor|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/indexing-doctor)|
|joinline / Joinline|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/joinline)|
|json-viewer / JSON Viewer|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/json-viewer)|
|just-these / Just These|A calm screen for kids that plays only the shows you picked. No autoplay, no feed.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/just-these)|
|kaching / KaChing|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/kaching)|
|katalyst-labs-llc / Lucenda|A digital health platform that turns patient discharge handouts into accessible, audio-narrated, and multi-language instructions delivered via QR code or phone line without requiring an app|未知|$0 / $0 / $756|D|[TrustMRR](https://trustmrr.com/startup/katalyst-labs-llc)|
|leeviios / LeeviiOS|A personal planning app for money, tasks, goals and habits, with a morning brief built from your own figures and an AI assistant that explains them.|未知|$12 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/leeviios)|
|linuxcert-guru / LINUXCERT.GURU|Prepare for Linux certifications through hands-on, auto-graded labs and timed mock exams on real Linux machines in your browser.|未知|$2,128 / $2.1k / $42k|D|[TrustMRR](https://trustmrr.com/startup/linuxcert-guru)|
|nevermind / Nevermind|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/nevermind)|
|no-missed-spots / No Missed Spots|No Missed Spots helps residential cleaning companies stop paying for re-cleans. Cleaners snap pictures of each room on their phone before leaving, AI checks the photo against that room’s checklist, an|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/no-missed-spots)|
|orionedits / orionedits|Claude sucks at editing video. So we gave it superpowers.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/orionedits)|
|ortento-inc / Qatika|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/ortento-inc)|
|piction / Piction AI|PictionAI is an app that uses AI to transform photos into artistic creations and personalized greeting cards.|未知|$0 / $0 / $33|D|[TrustMRR](https://trustmrr.com/startup/piction)|
|pippinry / Pippinry|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/pippinry)|
|plintus-ai / Plintus.ai|Design your own home in 3D from your floor plan, and try real furniture you can buy, at its true size.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/plintus-ai)|
|postpep / postpep.com|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/postpep)|
|preptics-llc / PREPTICS LLC|Preptics runs full-length adaptive Digital SAT mocks built the way the real test is built: two modules per section, the second routed by how you did on the first, on server-held clocks. Results come b|未知|$0 / $5 / $5|D|[TrustMRR](https://trustmrr.com/startup/preptics-llc)|
|private-enterprise-98 / Door a Day|web app that sells personalized digital advent calendars.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-enterprise-98)|
|private-enterprise-99 / Private Enterprise|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-enterprise-99)|
|private-venture-110 / intrat email client|Intray is an open-source email client that brings all your inboxes and AI tools together. Integrate existing subscriptions like Claude, ChatGPT, Codex, and local models without paying for another AI s|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/private-venture-110)|
|prodscene / Prodscene|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/prodscene)|
|purple-horizons-llc / HunchHunt|HunchHunt finds your best buyers. Enter your website or idea, and it forms buyer hypotheses and tests them against real conversations online, so you know who to sell to before you spend on ads|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/purple-horizons-llc)|
|rank-by-ai / Rank By AI|RankbyAI helps businesses and SEO agencies track their visibility across ChatGPT, Perplexity, Gemini, and Google Maps. Monitor rankings, analyze competitors, and generate white-label reports. Pay once, use forever. No subscriptions.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/rank-by-ai)|
|razorpay-business-20 / HARRY THE BLAZE|Harry The Blaze is a placement-prep platform for engineering students in India. Students practise company-style cognitive games and communication rounds, take AI mock interviews, and work through Infosys coding questions. When they're ready, they book a 20-minute call with a senior who was recently placed.|未知|$0 / $207 / $470|D|[TrustMRR](https://trustmrr.com/startup/razorpay-business-20)|
|razorpay-business-21 / Seller Autofill|SellerAutoFill is a powerful browser extension that automates product listing and data entry across Meesho, Amazon, Flipkart, and Shopify. Create product listings in seconds with one-click autofill, bulk listing templates, and automated SKU, GST, and pricing fields. Save time, simplify catalog management, and grow your e-commerce business with less manual work.|未知|$0 / $0 / $23|D|[TrustMRR](https://trustmrr.com/startup/razorpay-business-21)|
|red-candle-yearly / Red Candle Journal|Red Candle finds past charts in your own MT5 history that look like today's and shows how they played out. AI explains the structure in plain words, and your journal stays on your computer, never on our servers.|未知|$30 / $30 / $30|D|[TrustMRR](https://trustmrr.com/startup/red-candle-yearly)|
|rimal-software-llc / Tiny Arms|Tiny Arms is a T-rex that lives 24/7 on a TikTok-Live-style stream, and the whole internet has to keep it alive. It has tiny arms, so it can't feed itself. Anyone can feed it for free every 10 minutes|未知|$0 / $16 / $16|D|[TrustMRR](https://trustmrr.com/startup/rimal-software-llc)|
|riwada-limited / Riwada Limited|Adds automatically updating, customizable cricket and football score graphics, broadcast-style overlays, and production features to OBS livestreams.|未知|$150 / $145 / $145|D|[TrustMRR](https://trustmrr.com/startup/riwada-limited)|
|rumbodia / Rumbodia|Rumbo turns short daily updates about your goals into supportive scores, insights, and visual trends so you can track your direction over time.|未知|$0 / $0 / $1|D|[TrustMRR](https://trustmrr.com/startup/rumbodia)|
|rushly / Rushly AI|Rushly AI is a web app for people whose videos bring in business: coaches, consultants, founders, real estate agents, UGC creators. You film yourself talking to the camera, and Rushly AI edits the video like a pro, with no look that screams AI. Each video can become up to 5 Instagram trial reels, so you keep the version that gets the most views. You post 10x more without spending more time on it, …〔全文见JSON〕|未知|$27 / $67 / $2.7k|D|[TrustMRR](https://trustmrr.com/startup/rushly)|
|sahi / Sahi|Sahi is a mobile e-sign app (iOS and Android) for sending documents to other people to sign.  You import a PDF, place signature fields, and invite each signatory by phone or email. The invite goes out on WhatsApp or email with a signing link. The signatory opens it in the browser, verifies with a one-time code on that same channel, reviews the document, draws or types a signature, and signs or dec…〔全文见JSON〕|未知|$2 / $20 / $20|D|[TrustMRR](https://trustmrr.com/startup/sahi)|
|scrim / Scrim|Scrim is a macOS menu bar app that puts movable, resizable masks over any part of your screen, so sensitive or distracting content stays hidden during screen sharing, demos, recordings, livestreams an|未知|$0 / $4 / $18|D|[TrustMRR](https://trustmrr.com/startup/scrim)|
|serverdog / ServerDog|ServerDog is a native Mac app that creates and manages your own VPS servers, like a hosted server panel without the middleman. Create servers on Hetzner, DigitalOcean or Vultr, deploy Laravel, PHP and|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/serverdog)|
|shrunk / Shrunk|Hide-and-seek in your own home: a phone scan of a room becomes a 3D world where your friends hide, tiny, from one giant. Plays in the browser, up to 8 players.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/shrunk)|
|simplest / Simplest|Your always-on AI coding workspace. Connect GitHub, code with Claude from any device, and preview your apps—even with your laptop closed.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/simplest)|
|sole-trader / Counterstar|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/sole-trader)|
|soonly / Soonly|Simple booking for appointments and group sessions, with reminders that prevent no-shows.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/soonly)|
|spikecut / SpikeCut|SpikeCut watches and listens for the action, then cuts it into vertical clips with the face cam, captions and a hook.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/spikecut)|
|startup-5275e0c5358e / Anonymous startup|Transform any content into personalized learning materials in seconds with AI.|未知|$660 / $777 / $8.1k|D|[TrustMRR](https://trustmrr.com/startup/startup-5275e0c5358e)|
|statementtrust / StatementTrust \| Bank Statement Converter|StatementTrust is a privacy-first bank statement converter for small businesses, bookkeepers, and accountants. Convert PDF statements and scans from 1,000+ banks into clean Excel, CSV, OFX, QBO, and X|未知|$0 / $1 / $1|D|[TrustMRR](https://trustmrr.com/startup/statementtrust)|
|stealth-company-112 / Stealth Company|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/stealth-company-112)|
|stealth-company-113 / Stealth Company|Learn Russian through short daily practice.|未知|$88 / $328 / $421|D|[TrustMRR](https://trustmrr.com/startup/stealth-company-113)|
|stealth-company-114 / Stealth Company|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/stealth-company-114)|
|stealth-venture-73 / Stealth Venture|Automated Niche Digital Product, only requires an hour or so of customer support, a growing market and a well-defined audience. Organic Growth.|未知|$0 / $9.8k / $40k|D|[TrustMRR](https://trustmrr.com/startup/stealth-venture-73)|
|stoicsoft / StoicSoft|Twelve focused desktop apps for coding, design, video, marketing, servers and private AI. Each one runs on your own machine, and most of them hand their tools to the AI agent you already use (Claude C|未知|$19 / $1.3k / $10k|D|[TrustMRR](https://trustmrr.com/startup/stoicsoft)|
|supermailbox / SuperMailbox|SuperMailbox brings Gmail, iCloud Mail, Outlook, Yahoo Mail, Fastmail and other IMAP accounts into one inbox and connects them to ChatGPT, Claude and other compatible AI assistants through MCP. Find emails by meaning across languages, summarize threads and prepare replies, or manage your mail on the web.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/supermailbox)|
|symbiolearn / SymbioLearn|Talk through your study materials with an AI voice tutor that has read them all. Upload your PDFs, lecture slides, or YouTube videos to get 15-minute spoken lessons, flashcards, and quizzes tied directly to your notes.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/symbiolearn)|
|synapse / Synapse|Helps students improve their grades by turning their own notes into personalized quizzes, flashcards, study sheets, mind maps, and podcasts, with AI tutoring and progress tracking for parents.|未知|$766 / $1.1k / $12k|D|[TrustMRR](https://trustmrr.com/startup/synapse)|
|tabkeep / Tabkeep|The easy tab manager for your browser. this extension lives on your new tabs, you can save open tabs by drag and drop and reopen from new tab whenever. its local first, so its loads instantly.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/tabkeep)|
|talkr / talkr|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/talkr)|
|tastymcp / TastyMCP|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/tastymcp)|
|teaserkit / TeaserKit|TeaserKit is the director for your coding agent’s videos. Install it in one line and Claude Code, Codex, Cursor or Copilot can make a real launch film for your product. It picks a concept, a house sty|未知|$0 / $30 / $36|D|[TrustMRR](https://trustmrr.com/startup/teaserkit)|
|timer-anything / Timer Anything|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/timer-anything)|
|torty / Torty|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/torty)|
|touch-deck / Touch Deck|Turns an iPhone or iPad into a customizable control deck for a Mac, with shortcut keys, dials, sliders, a jog wheel, and multi-step workflows.|未知|$0 / $24 / $24|D|[TrustMRR](https://trustmrr.com/startup/touch-deck)|
|twinklecam / TwinkleCam|AI web app for parents at Christmas. Upload one photo of your living room and get a short night-camera style video of an elf or Santa caught in that room. Every clip is made by AI. Free preview first,|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/twinklecam)|
|underspend / Underspend|Track grocery spending in real time and stay within budget while shopping, even offline.|未知|$0 / $0 / $11|D|[TrustMRR](https://trustmrr.com/startup/underspend)|
|unnamed-company-75 / Anonymous startup|未知|未知|$0 / $0 / $869|D|[TrustMRR](https://trustmrr.com/startup/unnamed-company-75)|
|upparser / UpParser|UpParser uses AI to extract structured data from documents and automate data workflows.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/upparser)|
|walltator / Walltator|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/walltator)|
|welsenes-bros / ReddPanda|Guaranteed Reddit views from your future users. Done-for-you posts in the subreddits that fit your niche. ReddPanda keeps posting until you hit the views you paid for.|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/welsenes-bros)|
|wishus / WishUs|A QR guestbook where your guests leave photos, videos and voice notes, saved for you to open after the party|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/wishus)|
|wort / Wort|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/wort)|
|yourcut / Yourcut|未知|未知|$0 / $0 / $0|D|[TrustMRR](https://trustmrr.com/startup/yourcut)|
|fa-anon / Unnamed Company|未知|未知|— / 未知 / 未知|N|[TrustMRR](https://trustmrr.com/startup/fa-anon)|
