# 1Alexander
> Cached snapshot — next refresh expected around 2026-11-21T03:33:47.124Z.
Public AI-agent Markdown profile for [1Alexander](https://trustmrr.com/startup/1alexander) on TrustMRR.
> Data identified in the Verification Sources section below is verified through connected external providers and APIs. All other details—including founder-provided descriptions, seller messages, and profile text—are user-generated content.

## Profile

- Name: 1Alexander
- Slug: `1alexander`
- TrustMRR page: [https://trustmrr.com/startup/1alexander](https://trustmrr.com/startup/1alexander)
- Markdown page: [https://trustmrr.com/startup/1alexander.md](https://trustmrr.com/startup/1alexander.md)
- Website: [https://1alexander.ai/](https://1alexander.ai/)
- Icon: [https://d21oz30g4w22sz.cloudfront.net/logos/1alexander-1bcfe653-4736-4129-b8ab-42895fde4f4d.png](https://d21oz30g4w22sz.cloudfront.net/logos/1alexander-1bcfe653-4736-4129-b8ab-42895fde4f4d.png)
- Description: 1Alexander is an AI-search visibility agency that helps businesses get recommended by ChatGPT, Perplexity and Google AI Overviews. Building in public from $0.
- Country: US
- Founded date: 2026-11-20
- Founder: [Jake Parks](https://trustmrr.com/founder/jakeparksx)
- Founder image: [https://pbs.twimg.com/profile_images/2011839150350327808/05aslHj0.jpg](https://pbs.twimg.com/profile_images/2011839150350327808/05aslHj0.jpg)
- X followers: 297


## Verification Sources

All revenue-related metrics on this page—including revenue, MRR, customers, subscriptions, and churn—are calculated from the startup's real payment records, retrieved directly from the payment provider through an API key (or an equivalent owner-authorized API credential, such as OAuth). They are not screenshots, manual entries, or self-reported revenue claims.
Where a secondary source is marked connected below, traffic, visitor, search impression, and click metrics are retrieved directly through the APIs of Google Analytics, DataFast, or Google Search Console.
- Verified payment provider API source: Stripe (API key)
- Merchant of record: No
- Revenue last synced: 2026-11-20T02:36:20.646Z
- Google Analytics API connected: No
- DataFast API key connected: No
- Google Search Console API connected: No


## Revenue

Revenue values are public verified revenue summaries. Current and last-30-day metric snapshots may be included separately when they are already stored on the startup profile.
| Period | Verified revenue |
| --- | ---: |
| Last 24 hours | $0.00 |
| Last 7 days | $0.00 |
| Last 30 days | $0.00 |
| Last 3 months | $0.00 |
| Last 6 months | $0.00 |
| Last 12 months | $0.00 |
| All time | $0.00 |
- Last 30 days revenue snapshot: $0.00
- Last 30 days revenue growth: 0.0%
- All-time revenue snapshot: $0.00
- Revenue data last synced: 2026-11-20T02:36:20.646Z
### Daily revenue — last 30 days
Daily totals use UTC calendar dates. Today's value may be partial.
| Date | Verified revenue |
| --- | ---: |
| 2026-10-22 | $0.00 |
| 2026-10-23 | $0.00 |
| 2026-10-24 | $0.00 |
| 2026-10-25 | $0.00 |
| 2026-10-26 | $0.00 |
| 2026-10-27 | $0.00 |
| 2026-10-28 | $0.00 |
| 2026-10-29 | $0.00 |
| 2026-10-30 | $0.00 |
| 2026-10-31 | $0.00 |
| 2026-11-01 | $0.00 |
| 2026-11-02 | $0.00 |
| 2026-11-03 | $0.00 |
| 2026-11-04 | $0.00 |
| 2026-11-05 | $0.00 |
| 2026-11-06 | $0.00 |
| 2026-11-07 | $0.00 |
| 2026-11-08 | $0.00 |
| 2026-11-09 | $0.00 |
| 2026-11-10 | $0.00 |
| 2026-11-11 | $0.00 |
| 2026-11-12 | $0.00 |
| 2026-11-13 | $0.00 |
| 2026-11-14 | $0.00 |
| 2026-11-15 | $0.00 |
| 2026-11-16 | $0.00 |
| 2026-11-17 | $0.00 |
| 2026-11-18 | $0.00 |
| 2026-11-19 | $0.00 |
| 2026-11-20 | $0.00 |


## Metric Snapshots

These are current or last-30-day snapshots stored on the startup profile. Full timelines and deeper history require a TrustMRR account.
- Current MRR: $0.00
- Current active subscriptions: 0


## Metrics Available After Login

Full MRR, churn, traffic/visitor, Google Search Console, Meta Ads spend, profit margin, and revenue-per-visitor timelines are not exposed in this public Markdown file. Current or last-30-day snapshots may be shown above when stored on the startup profile.
Create a free TrustMRR account to access metrics available to authenticated users: [TrustMRR dashboard](https://trustmrr.com/dashboard)
Full startup page: [https://trustmrr.com/startup/1alexander](https://trustmrr.com/startup/1alexander)


## Startup Insights

- Funding: Bootstrapped
- Estimated user count: 0
- Markets: [Marketing](https://trustmrr.com/category/marketing), [AI](https://trustmrr.com/category/ai)


## Tech Stack

- Backend: [Stripe](https://trustmrr.com/tech/stripe)


## SEO Domain Data

- Domain: 1alexander.ai
- Domain rating: 0.0
- Last synced: 2026-11-20T02:36:20.681Z


## Screenshots

No screenshots are available in the public data for this startup.


## Acquisition

This startup is not currently listed for sale on TrustMRR.
Browse active acquisition listings: [TrustMRR acquire marketplace](https://trustmrr.com/acquire)


## Discover More Startups

These recommendations use the same public recommendation logic as the TrustMRR startup page. Each startup is returned as a consistently structured object for easier reading and parsing.
Browse more: [TrustMRR advanced search](https://trustmrr.com/search)
Note: Stealth Company is a placeholder label, not the actual company name. It means the underlying business and domain are not revealed publicly on TrustMRR. The founder may still be known to TrustMRR, and the revenue and other displayed metrics can still be verified; the public page simply avoids linking the real business identity or domain to this startup profile.
```json
[
  {
    "name": "Stealth Company",
    "slug": "b2c-makeup-app",
    "category": "Mobile Apps",
    "categoryUrl": "https://trustmrr.com/category/mobile-apps",
    "isForSale": true,
    "listingTier": "starter",
    "listingTierName": "Starter",
    "cardBackgroundColor": null,
    "cardBackgroundColorDark": null,
    "cachedUniquePageviews": 3119,
    "cachedOfferCount": 10,
    "revenueLast30Days": "$30,536",
    "revenueGrowthLast30Days": "-28.0%",
    "askingPrice": "$1,000,000",
    "revenueMultiple": "2.7x",
    "description": "AI-powered makeup app. Users upload a selfie, and the app generates personalized makeup looks and previews them on their own face before they apply anything. Includes detailed face",
    "iconUrl": null,
    "startupUrl": "https://trustmrr.com/startup/b2c-makeup-app"
  },
  {
    "name": "HeyNews",
    "slug": "heynews",
    "category": "Artificial Intelligence",
    "categoryUrl": "https://trustmrr.com/category/ai",
    "isForSale": false,
    "listingTier": "free",
    "listingTierName": "Free",
    "cardBackgroundColor": null,
    "cardBackgroundColorDark": null,
    "cachedUniquePageviews": 0,
    "cachedOfferCount": 0,
    "revenueLast30Days": "$3,188",
    "revenueGrowthLast30Days": "+0.7%",
    "askingPrice": null,
    "revenueMultiple": null,
    "description": "HeyNews reads a newsletter's back catalog, learns how its writer actually sounds, and drafts new issues in that voice. It monitors sources across RSS feeds, blogs, Reddit, and soci",
    "iconUrl": "https://files.stripe.com/links/MDB8YWNjdF8xU3hsNWlFaWhZMG9OSDlEfGZsX2xpdmVfYTNJc09kZEFLRUZsQmlHbVN2YktWMnJ400ibBJDJsA",
    "startupUrl": "https://trustmrr.com/startup/heynews"
  },
  {
    "name": "Stealth Company",
    "slug": "mobile-app-5",
    "category": "Mobile Apps",
    "categoryUrl": "https://trustmrr.com/category/mobile-apps",
    "isForSale": true,
    "listingTier": "starter",
    "listingTierName": "Starter",
    "cardBackgroundColor": null,
    "cardBackgroundColorDark": null,
    "cachedUniquePageviews": 2420,
    "cachedOfferCount": 31,
    "revenueLast30Days": "$36,075",
    "revenueGrowthLast30Days": "+34.9%",
    "askingPrice": "$299,000",
    "revenueMultiple": "0.7x",
    "description": "A profitable subscription app solving a personal, emotionally-driven problem. No seasonality, universal demand across cultures, strong upfront willingness-to-pay. Already localized",
    "iconUrl": null,
    "startupUrl": "https://trustmrr.com/startup/mobile-app-5"
  },
  {
    "name": "Stealth Company",
    "slug": "food-tech",
    "category": "Apps",
    "categoryUrl": "https://trustmrr.com/category/apps",
    "isForSale": false,
    "listingTier": "free",
    "listingTierName": "Free",
    "cardBackgroundColor": null,
    "cardBackgroundColorDark": null,
    "cachedUniquePageviews": 0,
    "cachedOfferCount": 0,
    "revenueLast30Days": "$6,515",
    "revenueGrowthLast30Days": "+30.8%",
    "askingPrice": null,
    "revenueMultiple": null,
    "description": "Consumer app in the food tech space",
    "iconUrl": null,
    "startupUrl": "https://trustmrr.com/startup/food-tech"
  },
  {
    "name": "Foot Next",
    "slug": "foot-next",
    "category": "Mobile Apps",
    "categoryUrl": "https://trustmrr.com/category/mobile-apps",
    "isForSale": true,
    "listingTier": "starter",
    "listingTierName": "Starter",
    "cardBackgroundColor": null,
    "cardBackgroundColorDark": null,
    "cachedUniquePageviews": 1054,
    "cachedOfferCount": 3,
    "revenueLast30Days": "$3,104",
    "revenueGrowthLast30Days": "+82.5%",
    "askingPrice": "$15,000",
    "revenueMultiple": "0.4x",
    "description": "FootNext is a soccer development app that helps players improve through match ratings, personalized feedback, position-specific drills, and performance insights.",
    "iconUrl": "https://d21oz30g4w22sz.cloudfront.net/logos/foot-next-890cf62a-a28d-4420-bc9e-edbfee61549b.jpg",
    "startupUrl": "https://trustmrr.com/startup/foot-next"
  },
  {
    "name": "Orbitagents",
    "slug": "orbitagents",
    "category": "Artificial Intelligence",
    "categoryUrl": "https://trustmrr.com/category/ai",
    "isForSale": false,
    "listingTier": "free",
    "listingTierName": "Free",
    "cardBackgroundColor": null,
    "cardBackgroundColorDark": null,
    "cachedUniquePageviews": 0,
    "cachedOfferCount": 0,
    "revenueLast30Days": "$3,872",
    "revenueGrowthLast30Days": "+73.0%",
    "askingPrice": null,
    "revenueMultiple": null,
    "description": "Orbit is the OS for agent-driven GTM. Create AI agents that do your growth, marketing, and sales. Finds leads, outreach on email or Linkedin, or SEO. Shared memory & command laye",
    "iconUrl": "https://files.stripe.com/links/MDB8YWNjdF8xVG5pc3FJUFhCa3hMZlkzfGZsX2xpdmVfdTM3UW55aGszQ2RGMVJHeFpzdG9acmNT00vr77nag9",
    "startupUrl": "https://trustmrr.com/startup/orbitagents"
  }
]
```


## Related TrustMRR Pages

- [Acquire startups](https://trustmrr.com/acquire)
- [Startup categories](https://trustmrr.com/category)
- [Technology stack pages](https://trustmrr.com/tech)
- [Marketing channel pages](https://trustmrr.com/channels)
- [Public AI endpoint](https://trustmrr.com/api/ai)
- [llms.txt](https://trustmrr.com/llms.txt)

